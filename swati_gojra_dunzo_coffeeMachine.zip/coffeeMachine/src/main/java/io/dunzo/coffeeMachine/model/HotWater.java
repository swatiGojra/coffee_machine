package io.dunzo.coffeeMachine.model;

/**
 *  @author swatigojra
 *
 */

public class HotWater extends Ingredient
{
   public HotWater(){
     super("hot_water", "Hot Water");
   }
}
