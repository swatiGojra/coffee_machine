package io.dunzo.coffeeMachine.model;

/**
 * @author swatigojra
 *
 */

public class ChocolateSyrup extends Ingredient
{
  public ChocolateSyrup(){
     super("chocolate_syrup", "Chocolate Syrup");
   }
}
