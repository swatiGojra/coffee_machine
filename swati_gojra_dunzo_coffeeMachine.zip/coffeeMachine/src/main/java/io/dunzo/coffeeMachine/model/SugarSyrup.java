/**
 * 
 */
package io.dunzo.coffeeMachine.model;

/**
 *  @author swatigojra
 *
 */

public class SugarSyrup extends Ingredient
{
   public SugarSyrup(){
     super("sugar_syrup", "Sugar Syrup");
   }
}
