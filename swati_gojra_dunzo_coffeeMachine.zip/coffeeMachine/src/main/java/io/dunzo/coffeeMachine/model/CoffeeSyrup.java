package io.dunzo.coffeeMachine.model;

/**
 *  @author swatigojra
 *
 */

public class CoffeeSyrup extends Ingredient
{
   public CoffeeSyrup(){
     super("coffee_syrup", "Coffee Syrup");
   }
}
