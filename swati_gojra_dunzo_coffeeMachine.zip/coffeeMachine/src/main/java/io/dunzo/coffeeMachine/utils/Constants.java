package io.dunzo.coffeeMachine.utils;

/**
 * @author swatigojra
 */
public class Constants
{
  public static final Integer CRITICAL_LIMIT = 100;

}
