package io.dunzo.coffeeMachine.exceptions;

/**
 * @author swatigojra
 *
 */
public class CoffeeMachineException extends Exception
{
	public CoffeeMachineException(String message){
		super(message);
	}
}
