package io.dunzo.coffeeMachine.exceptions;

/**
 * @author swatigojra
 *
 */
public class IngredientNotSupportedException extends Exception
{
	public IngredientNotSupportedException(String message){
		super(message);
	}
}
