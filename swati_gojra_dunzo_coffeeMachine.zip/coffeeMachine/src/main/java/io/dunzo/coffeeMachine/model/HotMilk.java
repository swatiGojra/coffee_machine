package io.dunzo.coffeeMachine.model;

/**
 *  @author swatigojra
 *
 */

public class HotMilk extends Ingredient
{
   public HotMilk(){
     super("hot_milk", "Hot Milk");
   }
}
